Hatta Mada — Arabic display font
Use for Arabic headlines and short display text.
Approved weight: 800.
