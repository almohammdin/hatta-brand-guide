El Messiri — English identity font
Included weights: 400, 600, 700.
